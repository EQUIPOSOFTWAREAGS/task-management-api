
using AutoMapper;

namespace TaskManagement.Application.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile() { }
}
