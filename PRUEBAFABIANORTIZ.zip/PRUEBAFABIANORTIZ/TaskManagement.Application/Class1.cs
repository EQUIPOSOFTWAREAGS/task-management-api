﻿namespace TaskManagement.Application;

public class Class1
{

}
