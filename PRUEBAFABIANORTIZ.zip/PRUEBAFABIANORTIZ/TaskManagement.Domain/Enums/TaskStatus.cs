
namespace TaskManagement.Domain.Enums;

public enum TaskStatus
{
    Pendiente,
    EnProgreso,
    Completada
}
