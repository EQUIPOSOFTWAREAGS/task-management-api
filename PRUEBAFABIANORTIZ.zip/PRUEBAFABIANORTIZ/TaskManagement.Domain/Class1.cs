﻿namespace TaskManagement.Domain;

public class Class1
{

}
