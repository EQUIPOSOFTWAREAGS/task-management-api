﻿namespace TaskManagement.Infrastructure;

public class Class1
{

}
